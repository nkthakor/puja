<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Puja Enterprise</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    .relative{
      margin-left: 11px;
      width: 100%;
    }
    .m-left{
      margin-left: -8px !important;
    }
  </style>
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center">
  <div class="bg-white shadow-2xl rounded-2xl max-w-md w-full p-8 space-y-6">
    <h1 class="text-4xl font-bold text-center text-gray-800 mb-4">Puja Enterprise</h1>
    <hr style="padding: 0;margin:0">
    <h2 class="text-3xl font-bold text-center text-gray-800 mb-6">Feedback Form</h2>
    
    <p class="text-sm text-center text-gray-600 font-medium mb-6">
        Outcome based service contract for mechanized cleaning, sanitation, disinfection, pest & rodent control, rag-picking, rank-vegetation cutting, garbage removal, transportation & disposal – <span class="font-semibold">Railway Hospital, Jodhpur</span>
    </p>
  
    <form class="space-y-4" id="feedback_form">
      <!-- Name Input -->
      <div class="relative">
        <input type="text" id="name" name="name" class="m-left block px-2.5 pb-1.5 pt-3 w-full text-sm text-gray-900 bg-transparent rounded-lg border border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " required />
        <label for="name" class="absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-3 scale-75 top-1 z-10 origin-[0] bg-white dark:bg-gray-900 px-2 peer-focus:px-2 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-1 peer-focus:scale-75 peer-focus:-translate-y-3">Name</label>
      </div>

      <!-- Designation Input -->
      <div class="relative">
        <input type="text" id="designation" name="designation" class="m-left block px-2.5 pb-1.5 pt-3 w-full text-sm text-gray-900 bg-transparent rounded-lg border border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " required />
        <label for="designation" class="absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-3 scale-75 top-1 z-10 origin-[0] bg-white dark:bg-gray-900 px-2 peer-focus:px-2 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-1 peer-focus:scale-75 peer-focus:-translate-y-3">Designation</label>
      </div>

      <!-- Mobile Number Input -->
      <div class="relative">
        <input type="tel" id="mobile" name="mobile" class="m-left block px-2.5 pb-1.5 pt-3 w-full text-sm text-gray-900 bg-transparent rounded-lg border border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " required />
        <label for="mobile" class="absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-3 scale-75 top-1 z-10 origin-[0] bg-white dark:bg-gray-900 px-2 peer-focus:px-2 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-1 peer-focus:scale-75 peer-focus:-translate-y-3">Mobile Number</label>
      </div>

      <!-- Location Input -->
      <div class="relative">
        <input type="text" id="location" name="location" class="m-left block px-2.5 pb-1.5 pt-3 w-full text-sm text-gray-900 bg-transparent rounded-lg border border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " required />
        <label for="location" class="absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-3 scale-75 top-1 z-10 origin-[0] bg-white dark:bg-gray-900 px-2 peer-focus:px-2 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-1 peer-focus:scale-75 peer-focus:-translate-y-3">Location</label>
      </div>

      <!-- Date Input -->
      <div class="relative">
        <input type="date" id="date" name="date" class="m-left block px-2.5 pb-1.5 pt-3 w-full text-sm text-gray-900 bg-transparent rounded-lg border border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" placeholder=" " required />
        <label for="date" class="absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-3 scale-75 top-1 z-10 origin-[0] bg-white dark:bg-gray-900 px-2 peer-focus:px-2 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-1 peer-focus:scale-75 peer-focus:-translate-y-3">Date</label>
      </div>

      <!-- Rating Input -->
      <div class="relative">
        <select id="rating" name="rating" class="m-left block px-2.5 pb-1.5 pt-3 w-full text-sm text-gray-900 bg-transparent rounded-lg border border-gray-300 appearance-none dark:text-white dark:border-gray-600 dark:focus:border-blue-500 focus:outline-none focus:ring-0 focus:border-blue-600 peer" required>
          <option value="">-- Select Rating --</option>
          <option>Excellent</option>
          <option>Very Good</option>
          <option>Good</option>
          <option>Average</option>
          <option>Poor</option>
        </select>
        <label for="rating" class="absolute text-sm text-gray-500 dark:text-gray-400 duration-300 transform -translate-y-3 scale-75 top-1 z-10 origin-[0] bg-white dark:bg-gray-900 px-2 peer-focus:px-2 peer-focus:text-blue-600 peer-focus:dark:text-blue-500 peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-1 peer-focus:scale-75 peer-focus:-translate-y-3">Rating</label>
      </div>

      <!-- Submit Button -->
      <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg transition duration-300 font-semibold">
        Submit
      </button>
    </form>

    <div class="text-blue-600 font-semibold" style="text-align: center;">
      <a href="<?php echo base_url("Feedback/view_all"); ?>" class="text-blue-500 hover:underline text-sm">View All Feedbacks</a>
    </div>

    <div class="text-center text-sm text-gray-500 mt-6">
      © 2025 Puja Enterprises. All rights reserved.
    </div>
  </div>
</body>
</html>

<script>
  $(document).ready(function () {
    $("#feedback_form").on("submit", function (e) {
      e.preventDefault();

      $.ajax({
        url: "<?php echo base_url('Feedback/submit') ?>",
        method: "POST",
        data: $(this).serialize(),
        dataType: "json",
        success: function (res) {
          if (res.status === "success") {
            Swal.fire({
              icon: 'success',
              title: 'Submitted!',
              text: 'Thank you for your feedback!',
              confirmButtonColor: '#3085d6'
            });
            $("#feedback_form")[0].reset();
          } else {
            Swal.fire({
              icon: 'error',
              title: 'Oops!',
              text: res.message || 'Submission failed. Please try again.',
              confirmButtonColor: '#d33'
            });
          }
        },
        error: function () {
          Swal.fire({
            icon: 'error',
            title: 'Server Error',
            text: 'Could not connect to the server.',
            confirmButtonColor: '#d33'
          });
        }
      });
    });
  });
</script>
