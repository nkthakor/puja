<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Puja Enterprise</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .review-card {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
            padding: 20px;
            margin-bottom: 20px;
            transition: transform 0.3s ease-in-out;
            box-shadow:0 5px 27px -7px rgb(0 0 0 / 0.25)
        }

        .review-card:hover {
            transform: scale(1.02);
        }

        .review-rating {
            background-color: #f3f4f6;
            padding: 4px 8px;
            border-radius: 12px;
            display: inline-block;
        }

        .review-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .review-name {
            font-size: 1.25rem;
            font-weight: 600;
            color: #2d3748;
        }

        .review-designation {
            font-size: 0.875rem;
            color: #718096;
        }

        .review-location {
            font-size: 0.875rem;
            color: #4a5568;
        }

        .review-feedback {
            margin-top: 12px;
            font-size: 1rem;
            color: #2d3748;
        }

        .pagination-btn {
            background-color: #3182ce;
            color: white;
            padding: 10px 20px;
            border-radius: 12px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .pagination-btn:hover {
            background-color: #2b6cb0;
        }

        .disabled-btn {
            background-color: #e2e8f0;
            color: #cbd5e0;
            cursor: not-allowed;
        }

        .search-box {
            margin-bottom: 20px;
            display: flex;
            justify-content: center;
            padding-left: 0;
            margin-left: -43px;
            width: 124%;
        }

        .search-input {
            padding: 8px 16px;
            border-radius: 8px;
            border: 1px solid #ccc;
            width: 80%;
            max-width: 400px;
        }
        
    </style>
</head>
<body class="bg-gray-50 min-h-screen flex items-center justify-center">
    <div class="bg-white shadow-xl rounded-lg max-w-4xl w-full p-8 space-y-6">
        <h1 class="text-4xl font-bold text-center text-gray-800 mb-6">Puja Enterprise</h1>
        <hr>
        <h2 class="text-3xl font-semibold text-center text-gray-800 mb-6">Feedback List</h2>

        <!-- Search Box -->
        <div class="search-box">
            <input type="text" id="search-input" class="search-input" placeholder="Search reviews...">
        </div>

        <div id="reviews-list"></div>

        <!-- Pagination Controls -->
        <div class="flex justify-center space-x-4 mt-6">
            <button id="prev-btn" class="pagination-btn disabled-btn" disabled>Previous</button>
            <button id="next-btn" class="pagination-btn">Next</button>
        </div>
    </div>

    <script>
        let currentPage = 1;
        const totalPages = <?= $total_pages ?>; // Pass total pages from backend
        let searchQuery = '';

        // Function to fetch and display reviews
        function fetchReviews(page, searchQuery = '') {
            $.ajax({
                url: `<?= base_url('feedback/fetch_reviews/') ?>${page}`,
                method: 'GET',
                dataType: 'json',
                data: { search: searchQuery }, // Send search query
                success: function(response) {
                    // Clear the previous reviews
                    $('#reviews-list').html('');

                    // Display new reviews
                    response.reviews.forEach(function(review) {
                        const reviewCard = `
                            <div class="review-card">
                                <div class="review-header">
                                    <div>
                                        <h3 class="review-name">${review.name}</h3>
                                        <p class="review-designation">Designation : ${review.designation}</p>
                                        <p class="review-designation">Location : ${review.location}</p>
                                        <p class="review-designation">Mobile No : ${review.mobile}</p>
                                    </div>
                                </div>
                                <div class="review-rating">Rating: ${review.rating}</div>
                            </div>
                        `;
                        $('#reviews-list').append(reviewCard);
                    });

                    // Update pagination buttons
                    if (page <= 1) {
                        $('#prev-btn').addClass('disabled-btn').prop('disabled', true);
                    } else {
                        $('#prev-btn').removeClass('disabled-btn').prop('disabled', false);
                    }

                    if (page >= totalPages) {
                        $('#next-btn').addClass('disabled-btn').prop('disabled', true);
                    } else {
                        $('#next-btn').removeClass('disabled-btn').prop('disabled', false);
                    }
                },
                error: function() {
                    Swal.fire('Error!', 'Could not load reviews', 'error');
                }
            });
        }

        // Handle pagination button clicks
        $('#next-btn').on('click', function() {
            if (currentPage < totalPages) {
                currentPage++;
                fetchReviews(currentPage, searchQuery);
            }
        });

        $('#prev-btn').on('click', function() {
            if (currentPage > 1) {
                currentPage--;
                fetchReviews(currentPage, searchQuery);
            }
        });

        // Search functionality
        $('#search-input').on('input', function() {
            searchQuery = $(this).val();
            fetchReviews(currentPage, searchQuery);
        });

        // Initial fetch
        fetchReviews(currentPage);
    </script>
</body>
</html>
