<header className="app-header">
    <div class="logo-placeholder">PUJA ENTERPRISES</div>
    <!-- <nav>
        <Link to="/">Home</Link>
        <Link to="/about">About Us</Link>
        <Link to="/feedbacks">Feedbacks</Link>
    </nav> -->
</header>