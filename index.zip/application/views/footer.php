<footer class="app-footer">
    <p>&copy; <?php echo date("Y"); ?> Puja Enterprises. All rights reserved.</p>
</footer>