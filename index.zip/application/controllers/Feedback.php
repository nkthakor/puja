<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Feedback extends CI_Controller {

    public $benchmark; // 👈 Add this line

    public function __construct()
    {
        parent::__construct();

        // Set session configuration here before any output
        //ini_set('session.cookie_lifetime', 3600);  // Set session cookie lifetime
        //session_start();  
    }
    public function index() {
      //  $this->load->view('header');
        $this->load->view('feedback_form');

    }
    public function view_all($page = 1) {
        // Define number of reviews per page
        $reviews_per_page = 5;
        $offset = ($page - 1) * $reviews_per_page;
    
        // Fetch the reviews from the database
        $reviews = $this->Feedback_model->get_reviews($reviews_per_page, $offset);
    
        // Count total reviews for pagination
        $total_reviews = $this->Feedback_model->count_reviews();
        $total_pages = ceil($total_reviews / $reviews_per_page);
    
        // Pass reviews and pagination data to the view
        $this->load->view('feedback_list', [
            'reviews' => $reviews,
            'total_pages' => $total_pages
        ]);
    }
    
      public function submit() {
        // Capture form inputs
        $name = $this->input->post('name', TRUE);
        $designation = $this->input->post('designation', TRUE);
        $mobile = $this->input->post('mobile', TRUE);
        $location = $this->input->post('location', TRUE); // changed from 'remarks'
        $date = $this->input->post('date'); // this is 'date_of_experience'
        $rating = $this->input->post('rating');
    
        // Prepare data array
        $data = [
            'name' => $name,
            'designation' => $designation,
            'mobile' => $mobile,
            'location' => $location,
            'date_of_experience' => $date,
            'rating' => $rating,
            //'created_at'>date('Y-m-d h:i A')
        ];
    
        // Save to DB
        $result = $this->Feedback_model->save($data);
    
        if ($result) {
            echo json_encode(['status' => 'success', 'message' => 'Feedback submitted successfully']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Error submitting feedback']);
        }
    }
    
    
    public function fetch_feedbacks() {
        // Fetch all feedbacks from the database
        $feedbacks = $this->Feedback_model->get_all_feedbacks();
    
        // Return data as JSON
        echo json_encode($feedbacks);
    }   
    public function fetch_reviews($page = 1) {
        // Define number of reviews per page
        $reviews_per_page = 5;
        // Calculate the offset based on the current page
        $offset = ($page - 1) * $reviews_per_page;
    
    
        // Fetch reviews from the model (passing limit and offset)
        $reviews = $this->Feedback_model->get_reviews($reviews_per_page, $offset);
    
        // Return reviews as JSON
        echo json_encode(['reviews' => $reviews]);
    }
    
     
}
?>