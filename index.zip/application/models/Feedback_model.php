<?php
class Feedback_model extends CI_Model {

    public function save($data) {
        return $this->db->insert('feedback', $data);
    }
    public function get_all_feedbacks() {
        return $this->db->get('feedback')->result_array(); // Fetch feedbacks from the feedback table
    }
    public function get_reviews($limit, $offset) {
        $this->db->limit($limit, $offset);
        $query = $this->db->get('feedback');
        return $query->result_array();
    }
    
    public function count_reviews() {
        return $this->db->count_all('feedback');
    }
}
